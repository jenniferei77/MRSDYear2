classdef policyGWM < Policy
    %POLICYGWM This policy implementes GWM for the bandit setting.
    
    properties
        nbActions % number of bandit actions
        t % current round 
        weights % weight vector to update
        lastAction % most recent action chosen
        % Add more member variables as needed
    end
    
    methods
        
        function init(self, nbActions)
            % Initialize any member variables
            self.nbActions = nbActions;
            self.t = 1;
            self.weights = ones(1, nbActions);
            self.lastAction = decision(self);
            
            % Initialize other variables as needed

        end
        
        function action = decision(self)
            % Choose an action according to multinomial distribution
            probs = self.weights/sum(self.weights);
            [~, action] = max(mnrnd(1, probs));
            self.lastAction = action;
        end
        
        function getReward(self, reward)
            % Update the weights
            eta = sqrt(log(self.nbActions)/self.t);
            
            % First we create the loss vector for GWM
            lossScalar = 1 - reward; % This is loss of the chosen action
            lossVector = zeros(1,self.nbActions);
            lossVector(self.lastAction) = lossScalar;
            
            % Do more stuff here using loss Vector
            self.weights = self.weights.*exp(-eta*lossVector);
            self.t = self.t + 1;
            
        end        
    end
end

