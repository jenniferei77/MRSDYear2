classdef policyEXP3 < Policy
    %POLICYEXP3 This is a concrete class implementing EXP3.
    
    properties
        nbActions % number of bandit actions
        weights % weight vector to update
        lastAction % most recent action chosen
        N
        % Define member variables
    end
    
    methods

        function init(self, nbActions)
            % Initialize member variables
            self.nbActions = nbActions;
            self.weights = ones(1, nbActions);
            self.lastAction = 0;
            self.N = 0;
        end
        
        function action = decision(self)
            % Choose an action
            probs = self.weights/sum(self.weights);
            [~, action] = max(mnrnd(1, probs));
            self.lastAction = action;
            self.N = self.N + 1;
        end
        
        function getReward(self, reward)
            % reward is the reward of the chosen action
            % update internal model
            eta = sqrt(log(self.nbActions)/(self.N*self.nbActions));
            lossScalar = 1 - reward; % This is loss of the chosen action
            probs = self.weights/sum(self.weights);
            lossBar = lossScalar/probs(self.lastAction);
            
            % Do more stuff here using loss Vector
            self.weights(self.lastAction) = self.weights(self.lastAction)*exp(-eta*lossBar);

        end        
    end
end