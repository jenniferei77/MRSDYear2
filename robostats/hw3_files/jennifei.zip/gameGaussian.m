classdef gameGaussian < Game
    %GAMEGAUSSIAN This is a concrete class defining a game where rewards a
    %   are drawn from a gaussian distribution.
    
    methods
        
        function self = gameGaussian(nbActions, totalRounds) 
            % Input
            %   nbActions - number of actions
            %   totalRounds - number of rounds of the game
            
            self.nbActions = nbActions;         % 2 actions
            self.totalRounds = totalRounds;    % 10000 time steps
            self.N = 0; % the current round counter is initialized to 0
            for i = 1:self.nbActions
                mu = rand;
                var = rand;
                self.tabR = [self.tabR; normrnd(mu, var, [1, self.totalRounds])]; 
            end
            self.tabR(self.tabR > 1) = 1;
            self.tabR(self.tabR < 0) = 0; % clipped table of total rewards
        end
        
    end    
end

