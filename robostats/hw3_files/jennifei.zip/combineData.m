function combo = combineData(set1, set2)
    loss1 = ones([size(set1,1), size(set2,2)]);
    loss2 = ones([size(set2,1), size(set1,2)]);
    combo1 = [set1, loss1];
    %labels1 = ones([1,set1])
    combo2 = [loss2, set2];
    %labels2 = zeros([1,set2]);
    %labels = [labels1, labels2];
    combo = [combo1; combo2];
    %combo = [combo; labels];
    combo(:, randperm(size(combo,2)));
    
    