classdef gameAdversarial<Game
    %GAMEADVERSARIAL This is a concrete class defining a game where rewards
    %   are adversarially chosen.

    methods
        
        function self = gameAdversarial(nbActions, totalRounds)
            self.nbActions = nbActions;         % 2 actions
            self.totalRounds = totalRounds;    % 1000 time steps
            self.tabR = ones(self.nbActions, self.totalRounds);
            self.N = 0; % the current round counter is initialized to 0
        end
            
        function [reward, action, regret] = playAdverse(self, policy, policyName)
            %   The function simulates the entire game where at each time
            %   step it class the policy to get an action, evaluates reward
            %   for that action and also evaluates regret for the policy
            %   till the timestep.
            %   Input:
            %       policy: An object of the policy class
            %   Output:
            %       reward: Rewards obtained by the policy (1xtotalRounds)
            %       action: Actions chosen by the policy (1xtotalRounds)
            %       regret: Regret of the policy (1xtotalRounds)
            
            policy.init(self.nbActions);            % Initialize the policy
            
            % Initialize rewards, actions, regret to 0
            reward = zeros(1, self.totalRounds);    
            action = zeros(1, self.totalRounds);
            regret = zeros(1, self.totalRounds);
            % Play the game
            for t = 1:self.totalRounds
                self.N = self.N + 1; % Update the current round counter
                action(t) = policy.decision(); % Get action from policy
                if strcmp(policyName, 'policyEXP3')
                    probs = policy.weights/sum(policy.weights);
                    [~, predictAction] = max(probs);
                else
                     predictAction = policy.decision();  
                end   
                self.tabR(predictAction, t) = 0.2;
                reward(t) = self.reward(action(t)); % Get reward for policy
                regret(t) = self.cumulativeRewardBestActionHindsight() - sum(reward); % Get regret
                policy.getReward(reward(t)); % Update policy
            end
        end
    end    
end

