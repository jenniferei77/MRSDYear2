classdef policyCombo < Policy
    %POLICYCOMBO This is a concrete class implementing UCB and EXP3.
        
    properties
        % Member variables
        state % current state
        counter % current counter
        t % current round
        alpha % exploration - exploitation tradeoff
        nbActions % number of actions
        lastAction
        weights
    end
    
    methods
        function init(self, nbActions)
            % Initialize
            self.nbActions = nbActions;
            self.t = 1;
            self.state = zeros(1, self.nbActions);
            self.counter = ones(1, self.nbActions);
            self.alpha = 1;
            self.lastAction = 1;
            self.weights = ones(1, nbActions);
        end
        
        function action = decision(self)
            % Choose action
            if (self.lastAction <= 760)
                probs = self.weights(1:760)/sum(self.weights(1:760));
                [~, action1] = max(mnrnd(1, probs));
                self.lastAction = action1;
                action = action1;
            else
                probs = self.weights(760:end)/sum(self.weights(760:end));
                [~, action2] = max(mnrnd(1, probs));
                self.lastAction = action2;
                action = action2;
            end
            self.t = self.t + 1;
        end
        
        function getReward(self, reward)
            % Update ucb
            if (self.lastAction <= 760)
                eta = sqrt(log(self.nbActions)/(self.t*self.nbActions));
                lossScalar = 1 - reward; % This is loss of the chosen action
                probs = self.weights(1:760)/sum(self.weights(1:760));
                lossBar = lossScalar/probs(self.lastAction);
            
                self.weights(self.lastAction) = self.weights(self.lastAction)*exp(-eta*lossBar);
            else
                eta = sqrt(log(self.nbActions)/(self.t*self.nbActions));
                lossScalar = 1 - reward; % This is loss of the chosen action
                probs = self.weights(760:end)/sum(self.weights(760:end));
                lossBar = lossScalar/probs(self.lastAction);
            
                self.weights(self.lastAction) = self.weights(self.lastAction)*exp(-eta*lossBar);
            end
        end        
    end

end
