classdef policyUCB < Policy
    %POLICYUCB This is a concrete class implementing UCB.

    properties
        % Member variables
        state % current state
        counter % current counter
        t % current round
        alpha % exploration - exploitation tradeoff
        nbActions % number of actions
        lastAction  
    end
    
    methods
        function init(self, nbActions)
            % Initialize
            self.nbActions = nbActions;
            self.t = 1;
            self.state = zeros(1, self.nbActions);
            self.counter = ones(1, self.nbActions);
            self.alpha = 1;
            self.lastAction = 1;
            
        end
        
        function action = decision(self)
            % Choose action
            if (self.t <= self.nbActions)
                action = self.t;
            else
                [~, action] = max((self.state./self.counter) + sqrt(self.alpha*(log(self.t)./(2*self.counter))));
            end
            self.lastAction = action;
            self.t = self.t + 1;
        end
        
        function getReward(self, reward)
            % Update ucb
            self.state(self.lastAction) = self.state(self.lastAction) + reward;
            self.counter(self.lastAction) = self.counter(self.lastAction) + 1;
        end        
    end

end
