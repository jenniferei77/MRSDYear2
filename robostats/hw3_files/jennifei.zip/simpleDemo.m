%% This script applies a random policy on a constant game
clc;
close; 
clear all;

load('univLatencies.mat')
load('plannerPerformance.mat');
combo = combineData(univ_latencies, planner_performance);

%% Get the constant game
%game = gameConstant();
%game = gameGaussian(10, 10000);
%game = gameAdversarial(2, 1000);

%game1 = gameLookupTable(univ_latencies, 1)
%game2 = gameLookupTable(planner_performance, 1);
game = gameLookupTable(combo, 1);

%% Get a set of policies to try out
% policies = {policyConstant(), policyRandom()};
% policy_names = {'policyConstant', 'policyRandom'};
% policies = {policyRandom(), policyGWM()};
% policy_names = {'policyRandom', 'policyGWM'};
%policies = {policyEXP3(), policyUCB(), policyRandom()};
%policy_names = {'policyEXP3', 'policyUCB', 'policyRandom'};
%policies = {policyEXP3(), policyUCB()};
%policy_names = {'policyEXP3', 'policyUCB'};
% policies = {policyGWM()};
% policy_names = {'policyGWM'};
%policies = {policyUCB()};
%policy_names = {'policyUCB'};
% policies = {policyEXP3()};
% policy_names = {'policyEXP3'};
policies = {policyCombo()};
policy_names = {'policyCombo'};

% %% Run the policies on the game
f1 = figure;
hold on;
f2 = figure;
hold on;
actions = zeros(length(policies));
for k = 1:length(policies)
    policy = policies{k};
    game.resetGame();
    [reward, action, regret] = game.play(policy);
    fprintf('Policy: %s Reward: %.2f\n', class(policy), sum(reward));
    figure(f1);   
    plot(regret);
    figure(f2);
    scatter((1:length(action)),action)
end
figure(f1);
legend(policy_names);
figure(f2);
legend(policy_names);

% for k = 1:length(policies)
%     policy = policies{k};
%     game1.resetGame();
%     game2.resetGame();
%     [reward, action, regret] = game1.play(policy);
%     figure(f1);   
%     plot(regret);
%     figure(f2);
%     scatter((1:length(action)),action)
%     [reward, action, regret] = game2.play(policy);
%     figure(f1);   
%     plot(regret);
%     figure(f2);
%     scatter((1:length(action)),action)
%     fprintf('Policy: %s Reward: %.2f\n', class(policy), sum(reward));
%     
% end
% figure(f1);
% legend(policy_names);
% figure(f2);
% legend(policy_names);




